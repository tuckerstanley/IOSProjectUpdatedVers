//
//  ViewController.swift
//  WorkoutApp
//
//  Created by Justin on 2020/12/13.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

